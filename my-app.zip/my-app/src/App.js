import React, { Component } from "react";
import { Row, Col } from "antd";
import "./App.css";
import Person from "./Person";
import jsonData from "./data.json";

class App extends Component {
  state = {
    users: [],
  };

  componentDidMount() {
    setTimeout(() => {
      this.setState({
        users: jsonData,
      });
    }, 2000);
  }

  deleteUser = (id) => {
    this.setState((prevState) => ({
      users: prevState.users.filter((entry) => entry.id !== id),
    }));
  };

  updateUser = (id, data) => {
    this.setState((prevState) => ({
      users: prevState.users.map((entry) => {
        if (entry.id === id) return { ...entry, ...data };
        return entry;
      }),
    }));
  };

  render() {
    const { users } = this.state;

    if (users.length === 0) {
      return (
        <div>
          <div className="spinner">
            <div className="bounce1" />
            <div className="bounce2" />
            <div className="bounce3" />
          </div>
        </div>
      );
    }

    return (
      <Row>
        {users.map((user) => (
          <Col xs={24} sm={24} md={8} lg={8} xl={6} key={user.username}>
            <Person
              user={user}
              deleteUser={this.deleteUser}
              updateUser={this.updateUser}
            />
          </Col>
        ))}
      </Row>
    );
  }
}

export default App;
